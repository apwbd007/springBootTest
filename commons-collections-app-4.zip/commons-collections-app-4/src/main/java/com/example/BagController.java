package com.example;

import org.apache.commons.collections4.Bag;
import org.apache.commons.collections4.bag.HashBag;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class BagController 

{

    private Bag<String> bag = new HashBag<>();

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("bag", bag);

        return "index";
    }

    @PostMapping("/add")
    public String addToBag(@RequestParam String item, @RequestParam int count, Model model) {
        bag.add(item, count);
        model.addAttribute("bag", bag);

        return "index";
    }
}
