package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonsCollectionsApp {


    public static void main(String[] args) {
        SpringApplication.run(CommonsCollectionsApp.class, args);

    }
}

